# This file intentionally left almost empty to avoid circular imports
# The blueprints are now defined in their respective route files
